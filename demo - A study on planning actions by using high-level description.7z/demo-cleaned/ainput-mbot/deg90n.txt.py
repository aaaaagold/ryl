def pull(ov):
	return min(abs(360-ov[0]),abs(ov[0]-0))
