def pullUR(ov): return abs(ov[1]-2)+abs(ov[2]-2)
def pullUL(ov): return abs(ov[1])+abs(ov[2]-2)
def pullDR(ov): return abs(ov[1]-2)+abs(ov[2])
def pullDL(ov): return abs(ov[1])+abs(ov[2])
