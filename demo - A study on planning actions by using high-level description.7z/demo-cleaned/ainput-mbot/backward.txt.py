def pull(ov):
	return abs(ov[2]+100)
