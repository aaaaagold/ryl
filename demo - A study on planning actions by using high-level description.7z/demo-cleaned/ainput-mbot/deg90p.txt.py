def pull(ov):
	return abs(ov[0]-180)
