#!/bin/python3
import sys
import copy
import time

from ag import *
#from ab import *
from a15p_rev import *
#from ab2g import *
from asol import *

xxx=Goaltree()
#xxx.fromTxt("ainput-15p-rev/main.txt")
xxx.fromTxt(sys.argv[1].replace("\\",'/'))
#print(xxx)
#print("toStr")
xxxtxt=xxx.toStr()
print(xxxtxt)
#xxx.fromStr(xxxtxt,cd='ainput-15p/')
#print(xxx.toStr())
print("#end")
print("finals:",xxx.getFinals())
print("size:",xxx.size())
bbb=board((4,4))
if 0!=0 or (len(sys.argv)>2 and sys.argv[2]=="1demo"):
	it=3
	step=int(sys.argv[it]) if len(sys.argv)>it and sys.argv[it].isdigit() else 8
	bbb.random()
	while bbb.solvable()==False: bbb.random()
	arr=[]
	#arr=[1, 3, 7, 12, 5, 15, 10, 0, 2, 4, 8, 11, 9, 6, 13, 14]
	#arr=[12, 8, 7, 6, 9, 13, 15, 3, 0, 1, 11, 10, 2, 14, 5, 4]
	if len(arr)!=0: bbb.setNums(arr,arr.index(15))
	bbb.print()
	#print(bbb.output()) , print(bbb.outputs()) , exit()
	print(bbb.rawBoard())
	t0=time.time()
	res=genSol_v3(bbb,xxx,step=step,stateLimit=4095,verbose=True)
	print(time.time()-t0)
	if len(res['moves'])==0:
		print("GG")
	else:
		movesS=res['moves']
		mml=min([len(mv) for mv in movesS])
		print(movesS,mml)
		for msg in res['mvSep'][0]:
			print("from-to")
			print(msg[0][0])
			print(msg[0][1])
			print()
			for m in msg[1]:
				move=m[1]
				print("move")
				print(move)
				print()
				bbb.move(move)
				print("board")
				bbb.print()
				print()
		print("move end")
		print()
		'''
		nodesS=res['nodes']
		for msg in movesS[0]:
			print("msg")
			print(msg)
			move=msg[1]
			#time.sleep(0.25)
			bbb.move(move)
			print("board")
			bbb.print()
			print()
		'''
		print(mml)
	pass
	exit()
# TODO 

if 0!=0:
	# debugging HLD
	notSolved=[
	]
	print("notSolved")
	for i in range(len(notSolved)):
		arr=notSolved[i]
		bbb.setNums(arr,arr.index(15))
		print(i,bbb.solvable())
		t0=time.time()
		res=genSol_v3(bbb,xxx,step=8)
		print(time.time()-t0)
		movesS=res['moves']
		nodesS=res['nodes']
		if len(movesS)==0:
			bbb.print()
			res=genSol_v3(bbb,xxx,step=8,verbose=True)
			movesS=res['moves']
			nodesS=res['nodes']
		else:
			print(movesS)
			print(nodesS)
		print(i)
		print()
else:
	# test several boards
	step=int(sys.argv[2]) if len(sys.argv)>2 and sys.argv[2].isdigit() else 8
	stateLimit=int(sys.argv[3]) if len(sys.argv)>3 and sys.argv[3].isdigit() else 4095
	print("need appearing 'goal!'."+
		("  %s=%s"%("step",str(step)))+
		("  %s=%s"%("stateLimit",str(stateLimit)))
		)
	succList=[]
	boardInitHistoryAll=[]
	boardInitHistory=[]
	failTime=[]
	failCnt=0
	bdcnt=0
	while 0==0:
		if bdcnt>999:
			for t in boardInitHistory:
				print(t[0].rawBoard(),t[1],t[2])
			def getmmma(arr):
				if len(arr)==0: return (None,None,None,None)
				sarr=sorted(arr)
				mi=len(sarr)>>1
				return sarr[-1],(sarr[mi] if len(sarr)&1 else (sarr[mi]+sarr[mi-1])/2.0),sarr[0],sum(arr)*1.0/len(arr)
			print("time: max,mid,min,avg =",getmmma([x[1] for x in boardInitHistory]))
			print("time_fail: max,mid,min,avg =",getmmma([x[1] for x in failTime]))
			print("step: max,mid,min,avg =",getmmma([x[3] for x in boardInitHistory]))
			print("fail count =",failCnt)
			exit()
		bdcnt+=1
		print("bdcnt",bdcnt)
		print("board.random()")
		bbb.random()
		while bbb.solvable()==False: bbb.random()
		bbb.print()
		print(bbb.rawBoard())
		t0=time.time()
		res=genSol_v3(bbb,xxx,step=step,stateLimit=stateLimit)
		t1=time.time()-t0
		succList+=res['nodes']
		mml=max([len(mv) for mv in res['moves']]+[-1])
		failCnt+=(mml<0)
		boardInitHistory.append((bbb.copy(),t1,res['nodes'],mml))
		print(t1,(res['moves']),mml)
		if len(res['moves'])==0:
			#res=genSol_v3(bbb,xxx,step=step,stateLimit=stateLimit,verbose=True)
			print(bbb.rawBoard())
			#break
			failTime.append(boardInitHistory.pop())
		elif 0!=0:
			movesS=res['moves']
			nodesS=res['nodes']
			print(nodesS)
			print(movesS)
			for i in range(len(nodesS)):
				moves=movesS[i]
				nodes=nodesS[i]
				print(nodes)
				print(moves)
				bbb.print()
				bbb.moveSeq(moves)
				print(len(moves))
		# [ [ "subgoal-path_A-1" , "subgoal-path_A-2" , ... ] , [ "subgoal-path_B-1" , "subgoal-path_B-2" , ... ] , ...]
