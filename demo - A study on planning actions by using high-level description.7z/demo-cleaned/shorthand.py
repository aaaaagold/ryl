#!/bin/python3
# common shortcuts
def isNone(x): return type(x)==type(None)
INF=float("inf")
INF_v1=[INF]
nINF_v1=[-INF]
INF_t1=(INF,)
nINF_t1=(-INF,)

